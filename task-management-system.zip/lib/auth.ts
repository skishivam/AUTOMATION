import { cookies } from "next/headers"
import { neon } from "@neondatabase/serverless"
import { redirect } from "next/navigation"
import bcrypt from "bcryptjs"

const sql = neon(process.env.DATABASE_URL!)

export type User = {
  id: number
  email: string
  name: string
}

export type Session = {
  user: User
}

// Get the current session
export async function getSession(): Promise<Session | null> {
  const cookieStore = cookies()
  const sessionToken = cookieStore.get("session_token")?.value

  if (!sessionToken) {
    return null
  }

  try {
    const user = await sql`
      SELECT id, email, name
      FROM users
      WHERE id = (SELECT user_id FROM sessions WHERE token = ${sessionToken} AND expires_at > NOW())
    `

    if (!user || user.length === 0) {
      return null
    }

    return { user: user[0] }
  } catch (error) {
    console.error("Error getting session:", error)
    return null
  }
}

// Create a new session
export async function createSession(userId: number): Promise<string> {
  const token = crypto.randomUUID()
  const expiresAt = new Date()
  expiresAt.setDate(expiresAt.getDate() + 30) // 30 days from now

  try {
    // First, check if we need to create the sessions table
    await sql`
      CREATE TABLE IF NOT EXISTS sessions (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        token VARCHAR(255) UNIQUE NOT NULL,
        expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `

    // Then create the session
    await sql`
      INSERT INTO sessions (user_id, token, expires_at)
      VALUES (${userId}, ${token}, ${expiresAt})
    `

    const cookieStore = cookies()
    cookieStore.set("session_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      expires: expiresAt,
      path: "/",
    })

    return token
  } catch (error) {
    console.error("Error creating session:", error)
    throw new Error("Failed to create session")
  }
}

// Delete the current session
export async function deleteSession() {
  const cookieStore = cookies()
  const sessionToken = cookieStore.get("session_token")?.value

  if (sessionToken) {
    try {
      await sql`
        DELETE FROM sessions
        WHERE token = ${sessionToken}
      `
    } catch (error) {
      console.error("Error deleting session:", error)
    }

    cookieStore.delete("session_token")
  }
}

// Register a new user
export async function registerUser(email: string, password: string, name: string): Promise<User> {
  // Check if user already exists
  const existingUser = await sql`
    SELECT id FROM users WHERE email = ${email}
  `

  if (existingUser && existingUser.length > 0) {
    throw new Error("User already exists")
  }

  // Hash the password
  const hashedPassword = await bcrypt.hash(password, 10)

  // Create the user
  const newUser = await sql`
    INSERT INTO users (email, password, name)
    VALUES (${email}, ${hashedPassword}, ${name})
    RETURNING id, email, name
  `

  if (!newUser || newUser.length === 0) {
    throw new Error("Failed to create user")
  }

  return newUser[0]
}

// Login a user
export async function loginUser(email: string, password: string): Promise<User> {
  // Find the user
  const users = await sql`
    SELECT id, email, name, password
    FROM users
    WHERE email = ${email}
  `

  if (!users || users.length === 0) {
    throw new Error("Invalid email or password")
  }

  const user = users[0]

  // Check the password
  const passwordMatch = await bcrypt.compare(password, user.password)

  if (!passwordMatch) {
    throw new Error("Invalid email or password")
  }

  // Return the user without the password
  const { password: _, ...userWithoutPassword } = user
  return userWithoutPassword
}

// Middleware to require authentication
export async function requireAuth() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  return session
}

