import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function generateTaskSuggestion(context: string, keywords?: string) {
  const prompt = `Based on the following context and keywords "${keywords || ""}", suggest a new task that would be relevant and helpful. Provide a brief description.

Context:
${context || "No context provided"}

Keywords: ${keywords || "None provided"}

Suggested task:`

  const { text } = await generateText({
    model: openai("gpt-4o"),
    prompt,
  })

  return text.trim()
}

