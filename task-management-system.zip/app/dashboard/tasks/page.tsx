import { getSession } from "@/lib/auth"
import { neon } from "@neondatabase/serverless"
import { TaskList } from "./task-list"
import { CreateTaskForm } from "./create-task-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const sql = neon(process.env.DATABASE_URL!)

export default async function TasksPage() {
  const session = await getSession()

  if (!session) {
    return null
  }

  const userId = session.user.id

  // Get all tasks for the user
  const tasks = await sql`
    SELECT 
      t.id, 
      t.title, 
      t.description, 
      t.status, 
      t.priority, 
      t.due_date, 
      t.created_at,
      COALESCE(json_agg(
        json_build_object(
          'id', w.id,
          'url', w.url,
          'title', w.title
        )
      ) FILTER (WHERE w.id IS NOT NULL), '[]') as websites
    FROM tasks t
    LEFT JOIN websites w ON t.id = w.task_id
    WHERE t.user_id = ${userId}
    GROUP BY t.id
    ORDER BY 
      CASE 
        WHEN t.status = 'pending' THEN 1
        WHEN t.status = 'in_progress' THEN 2
        WHEN t.status = 'completed' THEN 3
        ELSE 4
      END,
      CASE 
        WHEN t.priority = 'high' THEN 1
        WHEN t.priority = 'medium' THEN 2
        WHEN t.priority = 'low' THEN 3
        ELSE 4
      END,
      t.created_at DESC
  `

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Tasks</h1>
        <p className="text-muted-foreground">Manage your tasks and track your progress</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Create New Task</CardTitle>
            <CardDescription>Add a new task to your list</CardDescription>
          </CardHeader>
          <CardContent>
            <CreateTaskForm userId={userId} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Task List</CardTitle>
            <CardDescription>View and manage your tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <TaskList tasks={tasks} />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

