"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { createTask } from "../actions"
import { useRouter } from "next/navigation"

interface CreateTaskFormProps {
  userId: number
}

export function CreateTaskForm({ userId }: CreateTaskFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [priority, setPriority] = useState("medium")
  const [showWebsiteFields, setShowWebsiteFields] = useState(false)

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setIsLoading(true)
    setError(null)

    const formData = new FormData(event.currentTarget)
    formData.set("priority", priority)

    try {
      await createTask(formData, userId)
      event.currentTarget.reset()
      setPriority("medium")
      setShowWebsiteFields(false)
      router.refresh()
    } catch (error) {
      setError(error instanceof Error ? error.message : "Something went wrong")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="title">Task Title</Label>
        <Input id="title" name="title" placeholder="Enter task title" required />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea id="description" name="description" placeholder="Enter task description" rows={3} />
      </div>

      <div className="space-y-2">
        <Label htmlFor="priority">Priority</Label>
        <Select value={priority} onValueChange={setPriority}>
          <SelectTrigger id="priority">
            <SelectValue placeholder="Select priority" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="low">Low</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="high">High</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="dueDate">Due Date (Optional)</Label>
        <Input id="dueDate" name="dueDate" type="date" />
      </div>

      <div className="flex items-center space-x-2">
        <input
          type="checkbox"
          id="addWebsite"
          checked={showWebsiteFields}
          onChange={() => setShowWebsiteFields(!showWebsiteFields)}
          className="h-4 w-4 rounded border-gray-300"
        />
        <Label htmlFor="addWebsite" className="text-sm font-normal">
          Add a website link to this task
        </Label>
      </div>

      {showWebsiteFields && (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="websiteUrl">Website URL</Label>
            <Input id="websiteUrl" name="websiteUrl" placeholder="https://example.com" type="url" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="websiteTitle">Website Title (Optional)</Label>
            <Input id="websiteTitle" name="websiteTitle" placeholder="Example Website" />
          </div>
        </div>
      )}

      {error && <div className="p-3 text-sm text-white bg-red-500 rounded-md">{error}</div>}

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? "Creating..." : "Create Task"}
      </Button>
    </form>
  )
}

