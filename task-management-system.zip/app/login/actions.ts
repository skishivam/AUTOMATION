"use server"

import { createSession, loginUser } from "@/lib/auth"

export async function login(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  if (!email || !password) {
    throw new Error("Email and password are required")
  }

  try {
    const user = await loginUser(email, password)
    await createSession(user.id)

    return { success: true }
  } catch (error) {
    console.error("Login error:", error)
    throw new Error("Invalid email or password")
  }
}

