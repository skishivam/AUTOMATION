import { Button } from "@/components/ui/button"
import { getSession } from "@/lib/auth"
import { neon } from "@neondatabase/serverless"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

const sql = neon(process.env.DATABASE_URL!)

export default async function WebsitesPage() {
  const session = await getSession()

  if (!session) {
    return null
  }

  const userId = session.user.id

  // Get all websites for the user's tasks
  const websites = await sql`
    SELECT 
      w.id, 
      w.url, 
      w.title, 
      w.created_at,
      t.id as task_id,
      t.title as task_title,
      t.status as task_status
    FROM websites w
    JOIN tasks t ON w.task_id = t.id
    WHERE t.user_id = ${userId}
    ORDER BY w.created_at DESC
  `

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Websites</h1>
        <p className="text-muted-foreground">View all websites linked to your tasks</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Website Links</CardTitle>
          <CardDescription>All websites associated with your tasks</CardDescription>
        </CardHeader>
        <CardContent>
          {websites.length > 0 ? (
            <div className="space-y-4">
              {websites.map((website) => (
                <div key={website.id} className="p-4 border rounded-md">
                  <div className="flex justify-between items-start">
                    <div>
                      <a
                        href={website.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline font-medium"
                      >
                        {website.title || website.url}
                      </a>
                      <p className="text-sm text-muted-foreground mt-1 break-all">{website.url}</p>
                    </div>
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${
                        website.task_status === "completed"
                          ? "bg-green-100 text-green-800"
                          : website.task_status === "in_progress"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {website.task_status.replace("_", " ")}
                    </span>
                  </div>
                  <div className="mt-2">
                    <p className="text-sm">
                      Task:{" "}
                      <Link href="/dashboard/tasks" className="text-primary hover:underline">
                        {website.task_title}
                      </Link>
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Added on {new Date(website.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No websites found</p>
              <Link href="/dashboard/tasks">
                <Button className="mt-2">Add a task with website</Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

