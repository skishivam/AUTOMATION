"use client"

import { getSession } from "@/lib/auth"
import { neon } from "@neondatabase/serverless"
import { SuggestionGenerator } from "./suggestion-generator"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useSuggestion } from "../actions"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useEffect } from "react"

const sql = neon(process.env.DATABASE_URL!)

interface PageProps {
  searchParams: { [key: string]: string | string[] | undefined }
}

export default async function SuggestionsPage({ searchParams }: PageProps) {
  const session = await getSession()

  if (!session) {
    return null
  }

  const userId = session.user.id

  // Check if we need to use a suggestion
  const suggestionId = searchParams.use ? Number.parseInt(searchParams.use as string) : null

  useEffect(() => {
    async function handleUseSuggestion() {
      if (suggestionId && !isNaN(suggestionId)) {
        await useSuggestion(suggestionId, userId)
        redirect("/dashboard/tasks")
      }
    }
    handleUseSuggestion()
  }, [suggestionId, userId])

  // Get all suggestions for the user
  const suggestions = await sql`
    SELECT id, suggestion, keywords, created_at, used
    FROM task_suggestions
    WHERE user_id = ${userId}
    ORDER BY created_at DESC
  `

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">AI Task Suggestions</h1>
        <p className="text-muted-foreground">Get AI-powered suggestions for tasks based on keywords</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Generate Suggestions</CardTitle>
            <CardDescription>Enter keywords to get personalized task suggestions</CardDescription>
          </CardHeader>
          <CardContent>
            <SuggestionGenerator userId={userId} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Suggestions</CardTitle>
            <CardDescription>Your most recent AI-generated task suggestions</CardDescription>
          </CardHeader>
          <CardContent>
            {suggestions.length > 0 ? (
              <div className="space-y-4">
                {suggestions
                  .filter((s) => !s.used)
                  .map((suggestion) => (
                    <div key={suggestion.id} className="p-3 bg-primary/10 rounded-md">
                      <p>{suggestion.suggestion}</p>
                      {suggestion.keywords && (
                        <p className="text-xs text-muted-foreground mt-1">Keywords: {suggestion.keywords}</p>
                      )}
                      <div className="mt-2 text-right">
                        <Link href={`/dashboard/suggestions?use=${suggestion.id}`}>
                          <Button variant="outline" size="sm">
                            Use this
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}

                <div className="border-t pt-4 mt-4">
                  <h3 className="text-sm font-medium mb-2">Used Suggestions</h3>
                  {suggestions
                    .filter((s) => s.used)
                    .slice(0, 3)
                    .map((suggestion) => (
                      <div key={suggestion.id} className="p-3 bg-muted rounded-md mb-2">
                        <p className="text-muted-foreground">{suggestion.suggestion}</p>
                      </div>
                    ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No suggestions yet</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

