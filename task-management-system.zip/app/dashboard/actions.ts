"use server"

import { deleteSession } from "@/lib/auth"
import { neon } from "@neondatabase/serverless"
import { revalidatePath } from "next/cache"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

const sql = neon(process.env.DATABASE_URL!)

export async function logout() {
  await deleteSession()
}

export async function createTask(formData: FormData, userId: number) {
  const title = formData.get("title") as string
  const description = formData.get("description") as string
  const priority = formData.get("priority") as string
  const dueDate = formData.get("dueDate") as string
  const websiteUrl = formData.get("websiteUrl") as string
  const websiteTitle = formData.get("websiteTitle") as string

  if (!title) {
    throw new Error("Title is required")
  }

  try {
    // Create the task
    const task = await sql`
      INSERT INTO tasks (user_id, title, description, priority, due_date)
      VALUES (${userId}, ${title}, ${description}, ${priority}, ${dueDate ? new Date(dueDate) : null})
      RETURNING id
    `

    // If a website URL was provided, save it
    if (websiteUrl) {
      await sql`
        INSERT INTO websites (task_id, url, title)
        VALUES (${task[0].id}, ${websiteUrl}, ${websiteTitle || websiteUrl})
      `
    }

    revalidatePath("/dashboard/tasks")
    return { success: true, taskId: task[0].id }
  } catch (error) {
    console.error("Error creating task:", error)
    throw new Error("Failed to create task")
  }
}

export async function updateTaskStatus(taskId: number, status: string) {
  try {
    await sql`
      UPDATE tasks
      SET status = ${status}, 
          completed_at = ${status === "completed" ? new Date() : null}
      WHERE id = ${taskId}
    `

    revalidatePath("/dashboard/tasks")
    return { success: true }
  } catch (error) {
    console.error("Error updating task status:", error)
    throw new Error("Failed to update task status")
  }
}

export async function deleteTask(taskId: number) {
  try {
    await sql`
      DELETE FROM tasks
      WHERE id = ${taskId}
    `

    revalidatePath("/dashboard/tasks")
    return { success: true }
  } catch (error) {
    console.error("Error deleting task:", error)
    throw new Error("Failed to delete task")
  }
}

export async function generateTaskSuggestions(userId: number, keywords?: string) {
  try {
    // Get user's existing tasks for context
    const tasks = await sql`
      SELECT title, description
      FROM tasks
      WHERE user_id = ${userId}
      ORDER BY created_at DESC
      LIMIT 5
    `

    const taskContext = tasks.map((t) => `${t.title}: ${t.description || "No description"}`).join("\n")

    // Generate suggestions using AI
    const prompt = `Based on the following existing tasks and keywords "${keywords || ""}", suggest 3 new tasks that would be relevant and helpful. Format each suggestion on a new line with a brief description.

Existing tasks:
${taskContext || "No existing tasks yet"}

Keywords: ${keywords || "None provided"}

Suggested tasks:`

    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
    })

    // Parse the suggestions
    const suggestions = text
      .split("\n")
      .filter((line) => line.trim().length > 0)
      .map((line) => line.replace(/^\d+\.\s*/, "").trim())
      .slice(0, 3)

    // Save the suggestions to the database
    for (const suggestion of suggestions) {
      await sql`
        INSERT INTO task_suggestions (user_id, suggestion, keywords)
        VALUES (${userId}, ${suggestion}, ${keywords || null})
      `
    }

    revalidatePath("/dashboard/suggestions")
    return { success: true, suggestions }
  } catch (error) {
    console.error("Error generating suggestions:", error)
    throw new Error("Failed to generate task suggestions")
  }
}

export async function useSuggestion(suggestionId: number, userId: number) {
  try {
    // Get the suggestion
    const suggestions = await sql`
      SELECT suggestion
      FROM task_suggestions
      WHERE id = ${suggestionId} AND user_id = ${userId}
    `

    if (!suggestions || suggestions.length === 0) {
      throw new Error("Suggestion not found")
    }

    // Mark the suggestion as used
    await sql`
      UPDATE task_suggestions
      SET used = true
      WHERE id = ${suggestionId}
    `

    // Create a task from the suggestion
    const title = suggestions[0].suggestion.split(":")[0] || suggestions[0].suggestion
    const description = suggestions[0].suggestion.split(":")[1] || ""

    await sql`
      INSERT INTO tasks (user_id, title, description, priority)
      VALUES (${userId}, ${title.trim()}, ${description.trim()}, 'medium')
    `

    revalidatePath("/dashboard/suggestions")
    revalidatePath("/dashboard/tasks")
    return { success: true }
  } catch (error) {
    console.error("Error using suggestion:", error)
    throw new Error("Failed to use suggestion")
  }
}

