"use server"

import { createSession, registerUser } from "@/lib/auth"

export async function register(formData: FormData) {
  const name = formData.get("name") as string
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  if (!name || !email || !password) {
    throw new Error("All fields are required")
  }

  try {
    const user = await registerUser(email, password, name)
    await createSession(user.id)

    return { success: true }
  } catch (error) {
    console.error("Registration error:", error)
    if (error instanceof Error) {
      throw error
    }
    throw new Error("Failed to create account")
  }
}

