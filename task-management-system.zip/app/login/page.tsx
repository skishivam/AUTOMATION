import { LoginForm } from "./login-form"

export default function LoginPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-muted/40">
      <div className="w-full max-w-md p-8 space-y-8 bg-background rounded-lg shadow-lg">
        <div className="text-center">
          <h1 className="text-2xl font-bold">Login to AI Task Manager</h1>
          <p className="text-muted-foreground mt-2">Enter your credentials to access your account</p>
        </div>
        <LoginForm />
      </div>
    </div>
  )
}

