"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { updateTaskStatus, deleteTask } from "../actions"
import { useRouter } from "next/navigation"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

interface Website {
  id: number
  url: string
  title: string
}

interface Task {
  id: number
  title: string
  description: string | null
  status: string
  priority: string
  due_date: string | null
  created_at: string
  websites: Website[]
}

interface TaskListProps {
  tasks: Task[]
}

export function TaskList({ tasks }: TaskListProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState<Record<number, boolean>>({})

  if (!tasks || tasks.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">No tasks found</p>
      </div>
    )
  }

  const handleStatusChange = async (taskId: number, status: string) => {
    setIsLoading((prev) => ({ ...prev, [taskId]: true }))

    try {
      await updateTaskStatus(taskId, status)
      router.refresh()
    } catch (error) {
      console.error("Error updating task status:", error)
    } finally {
      setIsLoading((prev) => ({ ...prev, [taskId]: false }))
    }
  }

  const handleDelete = async (taskId: number) => {
    if (!confirm("Are you sure you want to delete this task?")) {
      return
    }

    setIsLoading((prev) => ({ ...prev, [taskId]: true }))

    try {
      await deleteTask(taskId)
      router.refresh()
    } catch (error) {
      console.error("Error deleting task:", error)
    } finally {
      setIsLoading((prev) => ({ ...prev, [taskId]: false }))
    }
  }

  return (
    <div className="space-y-4">
      <Accordion type="multiple" className="w-full">
        {tasks.map((task) => (
          <AccordionItem key={task.id} value={`task-${task.id}`}>
            <AccordionTrigger className="hover:no-underline">
              <div className="flex items-center justify-between w-full pr-4">
                <div className="flex items-center space-x-2">
                  <div
                    className={`w-3 h-3 rounded-full ${
                      task.priority === "high"
                        ? "bg-red-500"
                        : task.priority === "medium"
                          ? "bg-yellow-500"
                          : "bg-green-500"
                    }`}
                  />
                  <span
                    className={`font-medium ${task.status === "completed" ? "line-through text-muted-foreground" : ""}`}
                  >
                    {task.title}
                  </span>
                </div>
                <span
                  className={`px-2 py-1 text-xs rounded-full ${
                    task.status === "completed"
                      ? "bg-green-100 text-green-800"
                      : task.status === "in_progress"
                        ? "bg-blue-100 text-blue-800"
                        : "bg-yellow-100 text-yellow-800"
                  }`}
                >
                  {task.status.replace("_", " ")}
                </span>
              </div>
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4 pt-2">
                {task.description && (
                  <div>
                    <h4 className="text-sm font-medium">Description</h4>
                    <p className="text-sm text-muted-foreground">{task.description}</p>
                  </div>
                )}

                {task.due_date && (
                  <div>
                    <h4 className="text-sm font-medium">Due Date</h4>
                    <p className="text-sm text-muted-foreground">{new Date(task.due_date).toLocaleDateString()}</p>
                  </div>
                )}

                {task.websites && task.websites.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium">Websites</h4>
                    <ul className="space-y-1 mt-1">
                      {task.websites.map((website) => (
                        <li key={website.id}>
                          <a
                            href={website.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue-600 hover:underline"
                          >
                            {website.title || website.url}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="flex flex-wrap gap-2 pt-2">
                  {task.status !== "pending" && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatusChange(task.id, "pending")}
                      disabled={isLoading[task.id]}
                    >
                      Mark as Pending
                    </Button>
                  )}

                  {task.status !== "in_progress" && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatusChange(task.id, "in_progress")}
                      disabled={isLoading[task.id]}
                    >
                      Mark as In Progress
                    </Button>
                  )}

                  {task.status !== "completed" && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatusChange(task.id, "completed")}
                      disabled={isLoading[task.id]}
                    >
                      Mark as Completed
                    </Button>
                  )}

                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDelete(task.id)}
                    disabled={isLoading[task.id]}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  )
}

